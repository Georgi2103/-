# JupyterNoteebookForBinder
Jupyter Notebook для использования в Binder (на русском языке).

Для запуска Binder нажмите:
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/quiet-cmd/EmptyJupyterNoteebookForBinder/master)
